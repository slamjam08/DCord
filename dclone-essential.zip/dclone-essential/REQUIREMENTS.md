DClone Basic: Chat app like DChat, built with React, with more UI.
-> No limit on time, it starts with a YouTube series.
-> Needs to be progressive and feel good, not 3 hours and it'll work.

> Ability to chat with mock users, in a mock guild channel.
> -> Each version should have their individual bug fixes, instead of the full app.

1. Basic text channel

- Other browsers can chat with each other
  - as mock users
- Add basic messaging ability
  - w/ Mock CRUD

2. Add basic ui

- Sidebar with Discord-like environment

---

- Single mock guild text channel
- API: ability to chat as random user

# Flow

1. Go to website, and be assigned to random user
2. Type messages in chat
3. Other browsers can participate

---

# API

WS - message-create, message-delete, user-typing
