# Bug Report

**What**: (description of the bug)

e.g. Deleting user prevents logging in.

**When**: (steps to reproduce - the most important part)

e.g.

1. Click on 'App'
2. Click on user settings icon
3. Click 'Delete' user
4. Cannot login to user anymore

**Browser**: (e.g. Chrome / Firefox - including version is optional but helpful)

e.g. Chrome Version 92.0.4515.107 (Official Build) (64-bit)

( Can be found at [chrome://settings/help
](chrome://settings/help) )
