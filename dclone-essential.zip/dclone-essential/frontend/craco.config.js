module.exports = {
  plugins: [
    { plugin: require('craco-plugin-scoped-css') },
  ],
}