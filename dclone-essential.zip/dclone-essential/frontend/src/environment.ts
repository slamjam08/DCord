export default {
  apiURL: 'http://localhost:3000/api/v1',
  rootAPIURL: 'http://localhost:3000',
};